#!/usr/bin/env python3
import json
import os
import requests
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

LINE_CHANNEL_ACCESS_TOKEN = os.getenv('LINE_CHANNEL_ACCESS_TOKEN')
TEST_LINE_USER_ID = os.getenv('TEST_LINE_USER_ID')

def send_line_message(user_id, message):
    url = 'https://api.line.me/v2/bot/message/push'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {LINE_CHANNEL_ACCESS_TOKEN}'
    }
    data = {
        'to': user_id,
        'messages': [{'type': 'text', 'text': message}]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.status_code == 200

def format_datetime_full(datetime_str):
    """日時を「11月21日(金)12:30〜」形式に変換"""
    if '/' not in datetime_str:
        return datetime_str
    
    try:
        date_part, time_part = datetime_str.split('/')
        month = date_part
        day = time_part[:2]
        time = time_part[2:]
        
        if ':' not in time and len(time) >= 4:
            time = time[:2] + ':' + time[2:4]
        
        day_num = int(day)
        weekday_index = (day_num + 4) % 7
        weekdays = ['月', '火', '水', '木', '金', '土', '日']
        weekday = weekdays[weekday_index]
        
        return f"{month}月{day}日({weekday}){time}〜"
    except:
        return datetime_str

def clean_menu(menu):
    """メニュー名をクリーンアップ"""
    menu = menu.replace('【次回】', '').replace('【リピーター様】', '').replace('【4週間以内】', '').strip()
    if '¥' in menu:
        menu = menu.split('¥')[0]
    if '￥' in menu:
        menu = menu.split('￥')[0]
    return menu.strip()

def format_7days_message(booking):
    """7日前リマインドメッセージ"""
    customer_name = booking.get('お客様名', '').split('\n')[0].replace('★', '').strip()
    if '(' in customer_name:
        customer_name = customer_name.split('(')[0].strip()
    
    datetime_str = format_datetime_full(booking.get('来店日時', ''))
    menu = clean_menu(booking.get('メニュー', ''))
    
    message = f"""{customer_name} 様
ご予約【7日前】のお知らせ🕊️
{datetime_str}
{menu}

「マツエクが残っている」
「カールが残っている」
「眉毛の手入れをした…」
「仕事が入った」
など、ご予約日延期は、お早めにご協力をお願いします✨

＜次回予約特典が失効＞
予約日から3日前まで
前回来店日から3ヶ月経過

＜キャンセル料＞
◾️次回予約特典
当日変更：施術代金の50％
◾️通常予約
前日変更：施術代金の50％
当日変更：施術代金の100％"""
    return message.strip()

def format_3days_message(booking):
    """3日前リマインドメッセージ"""
    customer_name = booking.get('お客様名', '').split('\n')[0].replace('★', '').strip()
    if '(' in customer_name:
        customer_name = customer_name.split('(')[0].strip()
    
    datetime_str = format_datetime_full(booking.get('来店日時', ''))
    menu = clean_menu(booking.get('メニュー', ''))
    
    message = f"""{customer_name} 様
ご予約【3日前】のお知らせ🕊️
【本店】
{datetime_str}
{menu}

下記はすべてのお客様に気持ちよくご利用いただくためのご案内です。
ご理解とご協力をお願いいたします🙇‍♀️


■ 遅刻について
スタッフ判断でメニュー変更や日時変更となる場合があり
当日中の時間変更であれば、【次回予約特典】はそのまま適用可能

＜次回予約特典が失効＞
予約日から3日前まで
前回来店日から3ヶ月経過

＜キャンセル料＞
◾️次回予約特典
当日変更：施術代金の50％
◾️通常予約
前日変更：施術代金の50％
当日変更：施術代金の100％"""
    return message.strip()

def main():
    print("="*60)
    print("📬 予約リマインド通知送信（テストモード）")
    print("="*60)
    
    with open('scrape_result_3days.json', 'r', encoding='utf-8') as f:
        data_3days = json.load(f)
    bookings_3days = data_3days.get('bookings', [])
    print(f"\n📅 3日後の予約: {len(bookings_3days)}件")
    
    with open('scrape_result_7days.json', 'r', encoding='utf-8') as f:
        data_7days = json.load(f)
    bookings_7days = data_7days.get('bookings', [])
    print(f"📅 7日後の予約: {len(bookings_7days)}件")
    
    print(f"\n📤 神原さんにテスト送信中...\n")
    
    kambara_3days = [b for b in bookings_3days if '神原' in b.get('お客様名', '')]
    if kambara_3days:
        message = format_3days_message(kambara_3days[0])
        print("--- 3日後リマインド ---")
        print(message)
        print("-" * 40)
        if send_line_message(TEST_LINE_USER_ID, message):
            print("✅ 3日後リマインド送信成功\n")
        else:
            print("❌ 送信失敗\n")
    
    kambara_7days = [b for b in bookings_7days if '神原' in b.get('お客様名', '')]
    if kambara_7days:
        message = format_7days_message(kambara_7days[0])
        print("--- 7日後リマインド ---")
        print(message)
        print("-" * 40)
        if send_line_message(TEST_LINE_USER_ID, message):
            print("✅ 7日後リマインド送信成功\n")
        else:
            print("❌ 送信失敗\n")
    
    print("✅ テスト送信完了")

if __name__ == "__main__":
    main()
