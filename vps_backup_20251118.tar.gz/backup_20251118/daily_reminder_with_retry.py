#!/usr/bin/env python3
"""
リトライ機能付きリマインド送信（3回リトライ、15分間隔）
"""
import json
import os
import requests
import time
from datetime import datetime, timedelta
from playwright.sync_api import sync_playwright
from dotenv import load_dotenv

load_dotenv()

LINE_CHANNEL_ACCESS_TOKEN = os.getenv('LINE_CHANNEL_ACCESS_TOKEN')
ADMIN_LINE_USER_ID = os.getenv('TEST_LINE_USER_ID')

def send_line_message(user_id, message):
    url = 'https://api.line.me/v2/bot/message/push'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {LINE_CHANNEL_ACCESS_TOKEN}'
    }
    data = {
        'to': user_id,
        'messages': [{'type': 'text', 'text': message}]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.status_code == 200

def send_error_notification(date_str, days_label, error_msg):
    """エラー通知を管理者に送信"""
    message = f"""⚠️ システムエラー

{date_str}（{days_label}）の予約取得に失敗しました。
サロンボードをご確認ください。

エラー: {error_msg}
時刻: {datetime.now().strftime('%Y/%m/%d %H:%M')}"""
    
    send_line_message(ADMIN_LINE_USER_ID, message)
    print(f"❌ エラー通知送信: {date_str}")

def scrape_bookings_with_retry(date_str, max_retries=3, retry_interval=900):
    """リトライ機能付きスクレイピング（15分間隔）"""
    for attempt in range(1, max_retries + 1):
        print(f"\n[試行 {attempt}/{max_retries}] {date_str}の予約を取得中...")
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                
                with open('session_cookies.json', 'r') as f:
                    cookies = json.load(f)
                
                context = browser.new_context()
                context.add_cookies(cookies)
                page = context.new_page()
                
                url = f'https://salonboard.com/KLP/reserve/reserveList/searchDate?date={date_str}'
                page.goto(url, timeout=300000)
                page.wait_for_timeout(3000)
                
                rows = page.query_selector_all('table tbody tr')
                bookings = []
                
                for row in rows:
                    cells = row.query_selector_all('td')
                    if len(cells) < 4:
                        continue
                    
                    datetime_text = cells[0].text_content().strip()
                    customer_name = cells[2].text_content().strip()
                    
                    if datetime_text.isdigit() or not customer_name:
                        continue
                    
                    booking = {
                        'お客様名': customer_name,
                        '来店日時': datetime_text,
                        'メニュー': cells[4].text_content().strip() if len(cells) > 4 else ''
                    }
                    bookings.append(booking)
                
                browser.close()
                
                print(f"✅ 成功: {len(bookings)}件取得")
                return bookings, None
                    
        except Exception as e:
            error_msg = str(e)
            print(f"❌ 失敗: {error_msg}")
            
            if attempt < max_retries:
                print(f"⏳ {retry_interval // 60}分後にリトライ...")
                time.sleep(retry_interval)
            else:
                return None, error_msg
    
    return None, "最大リトライ回数に達しました"

def format_datetime_full(datetime_str):
    if '/' not in datetime_str:
        return datetime_str
    
    try:
        date_part, time_part = datetime_str.split('/')
        month = date_part
        day = time_part[:2]
        time = time_part[2:]
        
        if ':' not in time and len(time) >= 4:
            time = time[:2] + ':' + time[2:4]
        
        day_num = int(day)
        weekday_index = (day_num + 4) % 7
        weekdays = ['月', '火', '水', '木', '金', '土', '日']
        weekday = weekdays[weekday_index]
        
        return f"{month}月{day}日({weekday}){time}〜"
    except:
        return datetime_str

def clean_menu(menu):
    menu = menu.replace('【次回】', '').replace('【リピーター様】', '').replace('【4週間以内】', '').strip()
    if '¥' in menu:
        menu = menu.split('¥')[0]
    if '￥' in menu:
        menu = menu.split('￥')[0]
    return menu.strip()

def format_3days_message(booking):
    customer_name = booking.get('お客様名', '').split('\n')[0].replace('★', '').strip()
    if '(' in customer_name:
        customer_name = customer_name.split('(')[0].strip()
    
    datetime_str = format_datetime_full(booking.get('来店日時', ''))
    menu = clean_menu(booking.get('メニュー', ''))
    
    message = f"""{customer_name} 様
ご予約【3日前】のお知らせ🕊️
【本店】
{datetime_str}
{menu}

下記はすべてのお客様に気持ちよくご利用いただくためのご案内です。
ご理解とご協力をお願いいたします🙇‍♀️


■ 遅刻について
スタッフ判断でメニュー変更や日時変更となる場合があり
当日中の時間変更であれば、【次回予約特典】はそのまま適用可能

＜次回予約特典が失効＞
予約日から3日前まで
前回来店日から3ヶ月経過

＜キャンセル料＞
◾️次回予約特典
当日変更：施術代金の50％
◾️通常予約
前日変更：施術代金の50％
当日変更：施術代金の100％"""
    return message.strip()

def format_7days_message(booking):
    customer_name = booking.get('お客様名', '').split('\n')[0].replace('★', '').strip()
    if '(' in customer_name:
        customer_name = customer_name.split('(')[0].strip()
    
    datetime_str = format_datetime_full(booking.get('来店日時', ''))
    menu = clean_menu(booking.get('メニュー', ''))
    
    message = f"""{customer_name} 様
ご予約【7日前】のお知らせ🕊️
{datetime_str}
{menu}

「マツエクが残っている」
「カールが残っている」
「眉毛の手入れをした…」
「仕事が入った」
など、ご予約日延期は、お早めにご協力をお願いします✨

＜次回予約特典が失効＞
予約日から3日前まで
前回来店日から3ヶ月経過

＜キャンセル料＞
◾️次回予約特典
当日変更：施術代金の50％
◾️通常予約
前日変更：施術代金の50％
当日変更：施術代金の100％"""
    return message.strip()

def process_reminders(date_str, days_label, message_formatter):
    print(f"\n{'='*60}")
    print(f"[{days_label}] {date_str}のリマインド処理開始")
    print(f"{'='*60}")
    
    bookings, error = scrape_bookings_with_retry(date_str)
    
    if bookings is None:
        send_error_notification(date_str, days_label, error)
        return
    
    if len(bookings) == 0:
        print(f"⚠️ {days_label}: 予約が0件です")
        return
    
    sent_count = 0
    for booking in bookings:
        if '神原' in booking['お客様名']:
            message = message_formatter(booking)
            if send_line_message(ADMIN_LINE_USER_ID, message):
                print(f"✅ {booking['お客様名']} 送信成功")
                sent_count += 1
            else:
                print(f"❌ {booking['お客様名']} 送信失敗")
    
    print(f"📤 {sent_count}件送信完了")

print(f"\n{'='*60}")
print(f"リマインド送信システム起動")
print(f"実行時刻: {datetime.now().strftime('%Y/%m/%d %H:%M')}")
print(f"{'='*60}")

three_days_later = (datetime.now() + timedelta(days=3)).strftime('%Y%m%d')
process_reminders(three_days_later, "3日後", format_3days_message)

seven_days_later = (datetime.now() + timedelta(days=7)).strftime('%Y%m%d')
process_reminders(seven_days_later, "7日後", format_7days_message)

print(f"\n{'='*60}")
print("✅ 全ての処理が完了しました")
print(f"{'='*60}")
